# ToDo List for the Project

## Roles and Access

### Teacher

1. [ ] Login
2. [ ] Update Profile
3. [ ] Provide Internal Mark, Attendance, Syllabus, Notes
4. [ ] View Attendance, Syllabus, Subject Distribution, Time Schedule, Internal Mark

### HOD

1. [ ] Register Teacher and Advisor
2. [ ] Approve Teacher and Advisor
3. [ ] Provide Subject Distribution, Time Schedule
4. [ ] View Student Details [Internal Mark, Attendance] and Teacher Details[Attendance, Papers, Syllabus, Class] of the Department

### Admin

1. [ ] Approve HOD
2. [ ] Everything Else
