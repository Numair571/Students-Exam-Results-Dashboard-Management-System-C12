const allowedOrigins = [
  "https://kollege.onrender.com",
  "http://localhost:3000",
];
module.exports = allowedOrigins;
